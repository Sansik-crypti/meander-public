# Как получить APK Meander (Android)

В проекте уже есть полноценное Flutter-приложение `apps/main_app` и GitHub Actions workflow `.github/workflows/build_android.yml`, который собирает Android APK вместе с Rust-ядром. Python для этого проекта не нужен: переписывание на Python потеряло бы существующие редактор, плеер, интеграцию Rust и API.

## Самый простой способ — сборка в GitHub Actions

1. Распакуйте архив и загрузите содержимое репозитория в свой GitHub-репозиторий. Сохраните структуру каталогов, включая `.github/workflows/build_android.yml`.
2. На GitHub откройте вкладку **Actions**. Если появится предложение разрешить Actions, включите их.
3. В списке workflow выберите **Build Android APK**.
4. Нажмите **Run workflow**, выберите ветку и flavor `prod`, затем запустите сборку.
5. Дождитесь завершения job со статусом зелёной галочки.
6. Внизу страницы запуска откройте **Artifacts** и скачайте `meander-android`.
7. Распакуйте скачанный архив. APK будет внутри; файл называется примерно `meander-2.8.16-prod-arm64.apk` (точная версия зависит от `pubspec.yaml`). Скопируйте его на Android-телефон и установите.

### Важные ограничения

- Текущий workflow собирает APK для `arm64-v8a`, что подходит большинству современных Android-телефонов. Для старых 32-битных устройств нужна отдельная настройка ABI.
- Если в GitHub не настроены секреты подписи, workflow подписывает APK debug-ключом. Это подходит для тестирования и личной установки, но не является подписанным релизом для публикации в Google Play.
- APK скачивается из раздела Artifacts конкретного запуска Actions; он не создаётся заранее в этом архиве.
- Не публикуйте ключи подписи или пароли в репозитории.

## Сборка локально

Нужны Flutter версии, указанной в workflow, JDK 17, Android SDK/NDK, Rust toolchain с Android target и `cargo-ndk`. Из корня репозитория выполните:

```bash
dart pub global activate melos
melos bootstrap
rustup target add aarch64-linux-android
cargo install cargo-ndk --locked
bash ./scripts/build_quest_apk.sh quests/demo.mnd \
  --name "Meander Quest" \
  --id sbs.meander.quest.player \
  --abi arm64 \
  --out "$TMPDIR/meander-player"
mkdir -p apps/main_app/android/app/src/main/assets
cp "$TMPDIR/meander-player/sbs.meander.quest.player-1.0.0.apk" \
  apps/main_app/android/app/src/main/assets/quest_player_template.apk
cd apps/main_app
flutter pub get
flutter build apk --release --flavor prod \
  --target-platform android-arm64 \
  --android-project-arg=debugSignRelease=true \
  --android-project-arg=ffiAbis=arm64-v8a
```

После сборки проверьте `apps/main_app/build/app/outputs/flutter-apk/`.

## Что содержит эта модификация

- Базовый проект Meander (Flutter + Rust).
- Пресет темы `Meander Modern` с графитово-синим фоном и лаймовыми/циановыми акцентами.
- Этот файл с инструкциями по сборке APK.

Полный редизайн всех экранов не входит в этот первый этап. Rust-ядро и формат квестов не менялись.
