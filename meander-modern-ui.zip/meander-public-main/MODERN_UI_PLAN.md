# Meander Modern UI

## First implementation slice

This modification starts with the existing Flutter theme infrastructure rather than replacing the app shell or quest runtime.

- Adds the built-in `Meander Modern` theme preset in `apps/main_app/lib/core/theme/theme_registry.dart`.
- Uses a restrained graphite/navy dark surface, lime primary accent, and cyan secondary accent.
- Defines light-mode overrides as well, so the preset remains readable in both brightness modes.
- Makes `meander_modern` the fallback theme for first-time users. A previously saved theme selection remains respected by the existing provider.
- Leaves quest models, Rust core, save data, navigation, and APIs unchanged.

## Follow-up implementation plan

1. Audit existing home/library screens and preserve their current data providers.
2. Introduce shared UI tokens and reusable cards/buttons based on the new preset.
3. Refresh the main navigation for mobile and desktop without changing tab semantics.
4. Refresh the quest reader while preserving all existing choice actions and save behavior.
5. Add widget tests for responsive layouts, theme contrast, and navigation states.
6. Run `flutter analyze` and the relevant test suite in an environment with Flutter installed.

## Validation note

The current environment does not have the Flutter or Dart CLI installed, so `flutter analyze` and Flutter tests could not be run here. The change is intentionally limited to the existing `ThemePreset` configuration and uses role keys already supported by the theme engine.
